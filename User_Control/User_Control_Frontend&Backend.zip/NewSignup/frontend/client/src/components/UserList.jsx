import React, { useEffect, useState } from 'react';

function UserList() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchUsers = async () => {
    try {
      setLoading(true);
      setError('');
      const res = await fetch('http://localhost:4000/users');
      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      setError(`Failed to fetch users: ${err.message}`);
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const deleteUser = async (username) => {
    if (!window.confirm(`Are you sure you want to delete user '${username}'?`)) return;
    
    try {
      const res = await fetch(`http://localhost:4000/users/${username}`, { 
        method: 'DELETE' 
      });
      
      if (res.ok) {
        const result = await res.json();
        setUsers(users.filter(u => u.username !== username));
        alert(result.message || `User '${username}' deleted successfully!`);
      } else {
        const errorData = await res.json();
        alert(`Failed to delete user: ${errorData.error || errorData.details || 'Unknown error'}`);
      }
    } catch (err) {
      alert(`Error deleting user: ${err.message}`);
    }
  };

  if (loading) {
    return (
      <div className="user-list-container">
        <h3 className="section-title">User List</h3>
        <div className="loading-container">
          <span className="spinner"></span> Loading users...
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="user-list-container">
        <h3 className="section-title">User List</h3>
        <div className="error-message">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="user-list-container">
      <div className="section-header">
        <h3 className="section-title">User List</h3>
        <div className="user-count">
          {users.filter(u => u.host && u.host.trim() !== '').length} users
        </div>
      </div>
      
      {users.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">👤</div>
          <p>No users found</p>
        </div>
      ) : (
        <div className="table-container">
          <table className="user-table">
            <thead>
              <tr>
                <th>User</th>
                <th>Host</th>
                <th>Role</th>
                <th>Privileges</th>
                <th className="actions-header">Action</th>
              </tr>
            </thead>
            <tbody>
              {users.filter(u => u.host && u.host.trim() !== '').map(u => (
                <tr key={u.username}>
                  <td>{u.username}</td>
                  <td>{u.host}</td>
                  <td>
                    <span className={`role-badge ${u.role}`}>
                      {u.role}
                    </span>
                  </td>
                  <td>
                    <div className="privileges-container">
                      {u.privileges.slice(0, 4).map((p, i) => (
                        <div key={i} className="privilege-tag">
                          {translatePrivilege(p)}
                        </div>
                      ))}
                      {u.privileges.length > 4 && (
                        <div className="more-privileges">
                          +{u.privileges.length - 4} more
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="actions-cell">
                    <button 
                      onClick={() => deleteUser(u.username)}
                      className="delete-button"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function getRoleColor(role) {
  const colors = {
    'database_admin': '#dc3545',
    'developer': '#007bff',
    'analyst': '#28a745',
    'backup': '#ffc107',
    'read_only': '#6c757d',
    'unknown': '#6c757d'
  };
  return colors[role] || '#6c757d';
}

function translatePrivilege(privilege) {
  const roleBasedTranslations = {
    'ALL PRIVILEGES': 'Complete System Control',
    'SELECT': 'Read Database Data',
    'INSERT': 'Add New Data Records',
    'UPDATE': 'Modify Existing Data',
    'CREATE': 'Create Database Objects',
    'SHOW VIEW': 'View Database Views',
    'LOCK TABLES': 'Lock Tables During Backup',
    'EVENT': 'Manage Database Events',
    'TRIGGER': 'Manage Database Triggers'
  };

  if (privilege.includes('GRANT ALL PRIVILEGES ON')) {
    return 'Complete System Access';
  }
  
  if (privilege.includes('GRANT')) {
    const match = privilege.match(/GRANT\s+(.+?)\s+ON/);
    if (match) {
      const privs = match[1].split(',').map(p => p.trim());
      return privs.map(p => roleBasedTranslations[p] || p).join(', ');
    }
  }

  if (roleBasedTranslations[privilege]) {
    return roleBasedTranslations[privilege];
  }

  return privilege;
}

export default UserList;