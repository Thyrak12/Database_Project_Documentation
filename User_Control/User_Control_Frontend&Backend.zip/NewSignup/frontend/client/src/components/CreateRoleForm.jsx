import React, { useState } from 'react';

function CreateRoleForm({ onRoleCreated }) {
  const [form, setForm] = useState({ 
    roleName: '', 
    privileges: [],
    description: '' 
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const availablePrivileges = [
    'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP', 'INDEX',
    'ALTER', 'SHOW VIEW', 'LOCK TABLES', 'TRIGGER', 'EVENT', 'ALL PRIVILEGES'
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handlePrivilegeChange = (privilege) => {
    setForm(prev => {
      const newPrivileges = prev.privileges.includes(privilege)
        ? prev.privileges.filter(p => p !== privilege)
        : [...prev.privileges, privilege];
      return { ...prev, privileges: newPrivileges };
    });
  };

  const handleSelectAll = () => {
    setForm(prev => ({ ...prev, privileges: availablePrivileges }));
  };

  const handleClearAll = () => {
    setForm(prev => ({ ...prev, privileges: [] }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    
    if (form.privileges.length === 0) {
      setMessage('❌ Please select at least one privilege');
      setLoading(false);
      return;
    }
    
    try {
      const res = await fetch('http://localhost:4000/roles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roleName: form.roleName,
          privileges: form.privileges,
          description: form.description
        })
      });
      
      const result = await res.json();
      
      if (res.ok) {
        setMessage(`✅ Role '${form.roleName}' created successfully with ${form.privileges.length} privileges`);
        setForm({ roleName: '', privileges: [], description: '' });
        
        // Notify parent component that a new role was created
        if (onRoleCreated) {
          onRoleCreated(form.roleName);
        }
      } else {
        setMessage(`❌ Error: ${result.error || result.details || 'Failed to create role'}`);
      }
    } catch (error) {
      setMessage(`❌ Network Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="form-card">
      <h3 className="form-title">Create Custom Role</h3>
      <form onSubmit={handleSubmit} className="user-form">
        <div className="form-group">
          <label>Role Name</label>
          <input 
            name="roleName" 
            placeholder="Enter role name (e.g., custom_developer)" 
            value={form.roleName}
            onChange={handleChange} 
            required 
            disabled={loading}
            className="form-input"
          />
        </div>
        
        <div className="form-group">
          <label>Description</label>
          <textarea 
            name="description" 
            placeholder="Describe the role's purpose and responsibilities" 
            value={form.description}
            onChange={handleChange} 
            disabled={loading}
            className="form-input"
            rows="3"
          />
        </div>
        
        <div className="form-group">
          <label>Privileges</label>
          <div className="privilege-controls">
            <button 
              type="button" 
              onClick={handleSelectAll}
              disabled={loading}
              className="control-button"
            >
              Select All
            </button>
            <button 
              type="button" 
              onClick={handleClearAll}
              disabled={loading}
              className="control-button"
            >
              Clear All
            </button>
          </div>
          <div className="privileges-grid">
            {availablePrivileges.map(privilege => (
              <label key={privilege} className="privilege-checkbox">
                <input
                  type="checkbox"
                  checked={form.privileges.includes(privilege)}
                  onChange={() => handlePrivilegeChange(privilege)}
                  disabled={loading}
                />
                <span>{privilege}</span>
              </label>
            ))}
          </div>
          {form.privileges.length > 0 && (
            <div className="selected-privileges">
              <strong>Selected ({form.privileges.length}):</strong> {form.privileges.join(', ')}
            </div>
          )}
        </div>
        
        <button 
          type="submit" 
          disabled={loading || form.privileges.length === 0}
          className="submit-button"
        >
          {loading ? (
            <>
              <span className="spinner"></span> Creating Role...
            </>
          ) : (
            'Create Role'
          )}
        </button>
        
        {message && (
          <div className={`message ${message.includes('✅') ? 'success' : 'error'}`}>
            {message}
          </div>
        )}
      </form>
    </div>
  );
}

export default CreateRoleForm; 