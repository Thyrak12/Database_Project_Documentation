import React, { useState, useEffect } from 'react';

function CreateUserForm({ refreshTrigger, newlyCreatedRole }) {
  const [form, setForm] = useState({ username: '', password: '', role: 'developer' });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [customRoles, setCustomRoles] = useState([]);
  const [newRoleMessage, setNewRoleMessage] = useState('');

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  // Fetch custom roles function
  const fetchCustomRoles = async () => {
    try {
      const res = await fetch('http://localhost:4000/roles');
      if (res.ok) {
        const roles = await res.json();
        setCustomRoles(roles);
      }
    } catch (error) {
      console.error('Failed to fetch custom roles:', error);
    }
  };

  // Fetch custom roles on component mount and when refreshTrigger changes
  useEffect(() => {
    fetchCustomRoles();
  }, [refreshTrigger]);

  // Auto-select newly created role
  useEffect(() => {
    if (newlyCreatedRole && customRoles.some(role => role.name === newlyCreatedRole)) {
      setForm(prev => ({ ...prev, role: newlyCreatedRole }));
      setNewRoleMessage(`✅ New role "${newlyCreatedRole}" has been selected!`);
      
      // Clear the message after 3 seconds
      setTimeout(() => {
        setNewRoleMessage('');
      }, 3000);
    }
  }, [newlyCreatedRole, customRoles]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    
    try {
      const res = await fetch('http://localhost:4000/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      
      const result = await res.json();
      
      if (res.ok) {
        setMessage(`✅ ${result.message}`);
        setForm({ username: '', password: '', role: 'developer' });
        window.location.reload();
      } else {
        setMessage(`❌ Error: ${result.error || result.details || 'Failed to create user'}`);
      }
    } catch (error) {
      setMessage(`❌ Network Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="form-card">
      <h3 className="form-title">Create New User</h3>
      <form onSubmit={handleSubmit} className="user-form">
        <div className="form-group">
          <label>Username</label>
          <input 
            name="username" 
            placeholder="Enter username" 
            value={form.username}
            onChange={handleChange} 
            required 
            disabled={loading}
            className="form-input"
          />
        </div>
        
        <div className="form-group">
          <label>Password</label>
          <input 
            name="password" 
            placeholder="Enter password" 
            type="password" 
            value={form.password}
            onChange={handleChange} 
            required 
            disabled={loading}
            className="form-input"
          />
        </div>
        
        <div className="form-group">
          <label>Role</label>
          <select 
            name="role" 
            onChange={handleChange} 
            value={form.role}
            disabled={loading}
            className="form-select"
          >
            <optgroup label="Built-in Roles">
              <option value="developer">Developer</option>
              <option value="analyst">Analyst</option>
              <option value="backup">Backup</option>
              <option value="database_admin">Database Admin</option>
            </optgroup>
            {customRoles.length > 0 && (
              <optgroup label="Custom Roles">
                {customRoles.map(role => (
                  <option 
                    key={role.name} 
                    value={role.name}
                    className={role.name === newlyCreatedRole ? 'new-role-option' : ''}
                  >
                    {role.name} ({role.privileges.length} privileges)
                  </option>
                ))}
              </optgroup>
            )}
          </select>
        </div>
        
        <button 
          type="submit" 
          disabled={loading}
          className="submit-button"
        >
          {loading ? (
            <>
              <span className="spinner"></span> Creating...
            </>
          ) : (
            'Create User'
          )}
        </button>
        
        {newRoleMessage && (
          <div className="message success">
            {newRoleMessage}
          </div>
        )}
        
        {message && (
          <div className={`message ${message.includes('✅') ? 'success' : 'error'}`}>
            {message}
          </div>
        )}
      </form>
    </div>
  );
}

export default CreateUserForm;