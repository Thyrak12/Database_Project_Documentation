import React, { useState } from 'react';

function GrantPrivilegeForm() {
  const [form, setForm] = useState({ username: '', privilege: '', dbname: '' });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    
    try {
      const res = await fetch('http://localhost:4000/grant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      
      if (res.ok) {
        setMessage('✅ Privilege granted successfully!');
        setForm({ username: '', privilege: '', dbname: '' });
      } else {
        const errorData = await res.text();
        setMessage(`❌ Error: ${errorData}`);
      }
    } catch (error) {
      setMessage(`❌ Network Error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="form-card">
      <h3 className="form-title">Grant Privilege</h3>
      <form onSubmit={handleSubmit} className="user-form">
        <div className="form-group">
          <label>Username</label>
          <input 
            name="username" 
            placeholder="Enter username" 
            value={form.username}
            onChange={handleChange} 
            required 
            disabled={loading}
            className="form-input"
          />
        </div>
        
        <div className="form-group">
          <label>Database Name</label>
          <input 
            name="dbname" 
            placeholder="e.g., mydb" 
            value={form.dbname}
            onChange={handleChange} 
            required 
            disabled={loading}
            className="form-input"
          />
        </div>
        
        <div className="form-group">
          <label>Privilege</label>
          <select 
            name="privilege" 
            value={form.privilege}
            onChange={handleChange} 
            required 
            disabled={loading}
            className="form-select"
          >
            <option value="">Select Privilege</option>
            <option value="SELECT">SELECT</option>
            <option value="INSERT">INSERT</option>
            <option value="UPDATE">UPDATE</option>
            <option value="DELETE">DELETE</option>
            <option value="CREATE">CREATE</option>
            <option value="DROP">DROP</option>
            <option value="INDEX">INDEX</option>
            <option value="ALTER">ALTER</option>
            <option value="ALL PRIVILEGES">ALL PRIVILEGES</option>
          </select>
        </div>
        
        <button 
          type="submit" 
          disabled={loading}
          className="submit-button"
        >
          {loading ? (
            <>
              <span className="spinner"></span> Granting...
            </>
          ) : (
            'Grant Privilege'
          )}
        </button>
        
        {message && (
          <div className={`message ${message.includes('✅') ? 'success' : 'error'}`}>
            {message}
          </div>
        )}
      </form>
    </div>
  );
}

export default GrantPrivilegeForm;