import React, { useState } from 'react';
import CreateUserForm from './components/CreateUserForm';
import UserList from './components/UserList';
import GrantPrivilegeForm from './components/GrantPrivilegeForm';
import CreateRoleForm from './components/CreateRoleForm';
import './App.css';

function App() {
  const [roleUpdateTrigger, setRoleUpdateTrigger] = useState(0);
  const [newlyCreatedRole, setNewlyCreatedRole] = useState('');

  const handleRoleCreated = (roleName) => {
    setRoleUpdateTrigger(prev => prev + 1);
    setNewlyCreatedRole(roleName);
  };

  return (
    <div className="App">
      <h1>MySQL User Manager</h1>
      <CreateUserForm refreshTrigger={roleUpdateTrigger} newlyCreatedRole={newlyCreatedRole} />
      <hr />
      <CreateRoleForm onRoleCreated={handleRoleCreated} />
      <hr />
      <UserList />
      <hr />
      {/* <GrantPrivilegeForm /> */}
    </div>
  );
}

export default App;
